struct link_map_machine
  {
    size_t fptr_table_len;
    Elf64_Addr *fptr_table;
  };
