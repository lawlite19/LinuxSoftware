/* In s_lround.c.  */
