/* In s_lroundf.c.  */
