#define FUNC __ieee754_coshl
#define FUNC_FINITE __coshl_finite
#include <e_acosl.c>
