#define FUNC __ieee754_exp10
#define FUNC_FINITE __exp10_finite
#include <e_acos.c>
