#define FUNC __ieee754_asinl
#define FUNC_FINITE __asinl_finite
#include <e_acosl.c>
