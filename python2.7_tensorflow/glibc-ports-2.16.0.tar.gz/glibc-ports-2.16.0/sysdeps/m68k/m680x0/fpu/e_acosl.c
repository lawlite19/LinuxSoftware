#ifndef FUNC
# define FUNC __ieee754_acosl
# define FUNC_FINITE __acosl_finite
#endif
#define float_type long double
#include <e_acos.c>
