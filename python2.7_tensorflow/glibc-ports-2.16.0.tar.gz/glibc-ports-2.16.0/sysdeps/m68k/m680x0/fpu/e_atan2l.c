#define SUFF l
#define float_type long double
#include <e_atan2.c>
