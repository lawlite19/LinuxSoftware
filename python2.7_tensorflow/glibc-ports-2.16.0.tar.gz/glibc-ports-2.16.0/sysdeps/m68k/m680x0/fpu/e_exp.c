#define FUNC __ieee754_exp
#define FUNC_FINITE __exp_finite
#include <e_acos.c>
