#define FUNC __ieee754_asinf
#define FUNC_FINITE __asinf_finite
#include <e_acosf.c>
