#define FUNC __ieee754_coshf
#define FUNC_FINITE __coshf_finite
#include <e_acosf.c>
