/* __clz_tab not needed on hppa.  */
